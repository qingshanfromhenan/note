#!/bin/sh

cp /data/ddserver/tomcat/tomcat7-4380/tomcat-4380.service /usr/lib/systemd/system
chmod 555 /usr/lib/systemd/system/tomcat-4380.service
systemctl enable tomcat-4380
systemctl start tomcat-4380