#!/bin/sh

systemctl stop tomcat-4380
systemctl disable tomcat-4380
rm -f /usr/lib/systemd/system/tomcat-4380.service